#!/bin/bash
cd app
python -m http.server 1235