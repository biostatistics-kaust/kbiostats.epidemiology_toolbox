#!/bin/bash
http-server ./app -p 1235
